import pygame, random, time
import os, sys, Buttons, numpy
import menuClass
from pygame.locals import *
from operator import itemgetter
from itertools import groupby, combinations
from math import floor

#functions
def load_image(directory, name, colorkey=None):
	fullname = os.path.join(directory, name)
	try:
		image = pygame.image.load(fullname)
	except pygame.error:
		print('Cannot load image: ', name)
		raise SystemExit
	image = image.convert()
	if colorkey is not None:
		if colorkey is -1:
			colorkey = image.get_at((0,0))
		image.set_colorkey(colorkey, RLEACCEL)
	return image
def isJoker(num):
	return num%54 >=52
def specialSort(hand):
	sortedList = []
	for i in range(13):
		for cardInt in hand:
			if (cardInt%54)%13 == i and not cardInt%54 >=52:
				sortedList.append(cardInt)
	for cardInt in hand:
		if cardInt%54 >=52:
			sortedList.append(cardInt)
	return sortedList
def specialSortSubLists(superList):
	sortedList = []
	counter = 0
	for i in range(13):
		for element in superList:
			if (element[1]%54)%13==i and not isJoker(element[1]):
				sortedList.append([counter, element[1], element[2], element[3]])
				counter += 1
	for element in superList:
		if isJoker(element[1]):
			sortedList.append([counter, element[1], element[2], element[3]])
			counter += 1
	return sortedList
def getRandomDeckCards(deck, number=1):
	cardNum = len(deck)
	return specialSort([deck.pop(random.randrange(curDeckSize)) for curDeckSize in range(cardNum,cardNum-number,-1)])
def findSpread(handLength, highCoord, cushion = .125):
	center = int(highCoord/2)
	pixelCushion = int(round(highCoord * cushion, 0))
	distBetweenCards = 80
	substractVal = 0
	adderVal = 0
	if handLength%2 == 0: #if even
		if center + distBetweenCards/2 + distBetweenCards*(handLength/2-1) > highCoord-pixelCushion:
			distBetweenCards = int((highCoord-2*pixelCushion)/(handLength+1))
		substractVal = int(distBetweenCards/2 + distBetweenCards*(handLength/2-1))
		adderVal = int(distBetweenCards/2 + distBetweenCards*(handLength/2-1)+2)
	else:
		if center + distBetweenCards*((handLength-1)/2) > highCoord-pixelCushion:
			distBetweenCards = int((highCoord-2*pixelCushion)/(handLength+1))
		substractVal = int(distBetweenCards*((handLength-1)/2))
		adderVal = int(distBetweenCards*((handLength-1)/2)+2)
	return range(center - substractVal, center + adderVal, distBetweenCards)
def displayAIcards():
	#display left
	xvalues = int(screenDimensions[0]*.05-cardDimensions[1]/4)
	yvalues = findSpread(len(AICards[0]), screenDimensions[1])
	for yCoord in yvalues:
		screen.blit(pygame.transform.rotate(backOfCardSmall,90), (xvalues, yCoord-cardDimensions[1]/4))
	#top
	xvalues = findSpread(len(AICards[1]), screenDimensions[0], cushion = .2)
	yvalues = int(screenDimensions[1]*.05-cardDimensions[1]/4)
	for xCoord in xvalues:
		screen.blit(backOfCardSmall, (xCoord-cardDimensions[0]/4, yvalues))
	#right
	xvalues = int(screenDimensions[0]*.95-cardDimensions[1]/4)
	yvalues = findSpread(len(AICards[2]), screenDimensions[1])
	for yCoord in yvalues:
		screen.blit(pygame.transform.rotate(backOfCardSmall,-90), (xvalues, yCoord-cardDimensions[1]/4))
def displayBottom():
	slotCounter = 0
	xvalues = findSpread(len(playerCards), screenDimensions[0])
	yvalue = int(screenDimensions[1]*.9-cardDimensions[1]/2)

	# 0-9 , 0-107, T/F, Rects
	for xCoord in xvalues:
		yadd = playerCards[slotCounter][2]*10
		image = cardHighLights[playerCards[slotCounter][1]%54] if playerCards[slotCounter][2] else cardImages[playerCards[slotCounter][1]%54]
		playerCards[slotCounter][3] = screen.blit(image, (xCoord-cardDimensions[0]/2, yvalue - yadd))
		slotCounter += 1
def displayPilecards():
	transCoord = (int(screenDimensions[0]/2-cardDimensions[0]/2-cardDimensions[0]/1.5), int(screenDimensions[1]/2.7-cardDimensions[1]/4))
	rectPile = []
	if pileCards:
		rectPile.append(screen.blit(cardImages[pileCards[-1]%54], transCoord))
	else:
		rectPile.append(screen.blit(transcard, transCoord))
	rectPile.append(screen.blit(backOfCard, (int(screenDimensions[0]/2-cardDimensions[0]/2+cardDimensions[0]/1.5),transCoord[1])))
	return rectPile
def printSmallAICards():
	global 	downAICards, smallCardImages, downAICardsCoordinates, screenDimensions, cardDimensions
	#left, top, right	
	yvalue = 100
	setXValue = 90	
	if downAICards[0]:
		for eachDownSet in downAICards[0]:
			cardXValues = findSpread(len(eachDownSet), 120)
			for xCoord, tripleCard in zip(cardXValues, eachDownSet):
				cardInt = 52 if tripleCard[1] > 107 else tripleCard[1]%54
				image = smallCardImages[cardInt]
				tripleCard[2] = screen.blit(image, (xCoord-cardDimensions[0]/4+setXValue, yvalue))
			yvalue += 70
			
	yvalue = 100
	setXValue = 200
	if downAICards[1]:
		for eachDownSet in downAICards[1]:
			cardXValues = findSpread(len(eachDownSet), 120)
			for xCoord, tripleCard in zip(cardXValues, eachDownSet):
				cardInt = 52 if tripleCard[1] > 107 else tripleCard[1]%54
				image = smallCardImages[cardInt]
				tripleCard[2] = screen.blit(image, (xCoord-cardDimensions[0]/4+setXValue, yvalue))
			setXValue += 110
	yvalue = 100
	setXValue = 780
	if downAICards[2]:
		for eachDownSet in downAICards[2]:
			cardXValues = findSpread(len(eachDownSet), 120)
			for xCoord, tripleCard in zip(cardXValues, eachDownSet):
				cardInt = 52 if tripleCard[1] > 107 else tripleCard[1]%54
				image = smallCardImages[cardInt]
				tripleCard[2] = screen.blit(image, (xCoord-cardDimensions[0]/4+setXValue, yvalue))
			yvalue += 70
def pickFromDeck(hand):
	return specialSort(hand + getRandomDeckCards(DeckCards, 1))
def checkForDuplicates(rawSelected, returnList = False):
	editedRawSelected = [x%54 for x in rawSelected if not isJoker(x)]	
	listOfDuplicates = list(set([x for x in editedRawSelected if editedRawSelected.count(x) > 1]))
	if returnList:
		return listOfDuplicates
	else:
		return len(listOfDuplicates)
def onlyOneSuit(rawSelected):
	suitNumber = -1
	for cardNumber in rawSelected:
		if not isJoker(cardNumber):
			suitNumber = floor((cardNumber%54)/13)
			break
	if suitNumber==-1 and len(rawSelected):
		return True
	for cardNumber in rawSelected:
		if not isJoker(cardNumber) and floor((cardNumber%54)/13) != suitNumber:
			return False
	return True
def checkForPairs(rawSelected):
	for cardNumber in rawSelected:
		if not isJoker(cardNumber):
			cardNumbSuit = (cardNumber%54)%13
			break

	numberOfSuit = [[],[],[],[]]
	countOfSuit = [0,0,0,0]
	jokerList = []
	pairList = []

	for card in rawSelected:
		if isJoker(card):
			jokerList.append(card)
		elif (card%54)%13 == cardNumbSuit:
			suitNumber = int(floor((card%54)/13))
			countOfSuit[suitNumber] += 1
			numberOfSuit[suitNumber].append(card)
		else:
			return False

	jokerNumb = len(jokerList)
	optionalJokersPresent = False
	
	if min(countOfSuit) == 0 and max(countOfSuit) >= 2 and jokerNumb < countOfSuit.count(0):
		return False

	for isSecondSet in range(1+(len(rawSelected)>4)):
		possibleOpenings = []
		for x in range(4):
			if numberOfSuit[x]:
				pairList.append(numberOfSuit[x].pop())
			else:
				possibleOpenings.append(isSecondSet*4 + x)
				pairList.append(-1)
		if len(possibleOpenings) <= jokerNumb:
			for index in possibleOpenings:
				jokerNumb -= 1
				pairList[index] = (index%4)*13+cardNumbSuit + 108

	if jokerNumb:
		if len(possibleOpenings) <= jokerNumb:
			for index in possibleOpenings:
				if jokerNumb:
					jokerNumb -= 1
					pairList[index] = (index%4)*13+cardNumbSuit + 108
				else:
					break
		elif len(possibleOpenings) > jokerNumb:
			print("POSSIBLE", possibleOpenings, cardNumbSuit)
			pairList.append([jokerList[:jokerNumb], [((x%4)*13+cardNumbSuit)%54 for x in possibleOpenings]])
			optionalJokersPresent = True
			jokerNumb = 0
			#ask location of joker
	pairList = [i for i in pairList if i != -1]

	if not jokerNumb:
		return [False,optionalJokersPresent,pairList]
	return False
def isSequence(rawSelected):
	rawSelected = specialSort(rawSelected)

	cardGroups = []
	jokerList = []
	replaceCards = []

	for cardNumber in rawSelected:
		if isJoker(cardNumber):
			jokerList.append(cardNumber)
		else:
			cardGroups.append(cardNumber%54)
			if cardNumber/53 > 1 :
				replaceCards.append([cardNumber%54, cardNumber])
	#if the hand only contains joker it is valid
	if jokerList and not cardGroups:
		return jokerList

	jokerNumb = len(jokerList)

	#adapted from: http://stackoverflow.com/questions/2154249/identify-groups-of-continuous-numbers-in-a-list
	ranges = [list(map(itemgetter(1), g)) for k,g in groupby(enumerate(cardGroups), lambda i:i[0]-i[1])]
	if len(ranges)-1>jokerNumb:
		return False

	series = ranges[0]

	for x in range(len(ranges)):
		try: difference = ranges[x+1][0] - ranges[x][-1] -1
		except IndexError: break

		if jokerNumb < difference:
			return False
		for diffNumber in range(difference):
			series.append(ranges[x][-1] + 109) #Adding 108 indicates the joker status and the extra one for the array slot
			jokerNumb -= 1
		series += ranges[x+1]

	print("RANGES", ranges, "SERIES", series)

	#get rid of any leftover jokers
	optionalJokers = [[],[]]
	#format optionalJokers = [[JOKERLIST], [POSSIBLE PLACES TO PLAY]]
	if jokerNumb:
		while(jokerNumb):
			isKing = (series[-1]%54)%13 < 12
			isAce  = (series[0]%54)%13 > 0
			numberOfOptions = isKing + isAce
			jokerNumb -= 1
			if numberOfOptions==2:
				optionalJokers[0].append(jokerList[jokerNumb])
				if not optionalJokers[1]:
					optionalJokers[1] = [series[0]%54-1,series[-1]%54+1]
			elif isKing:
				series.append(jokerList[jokerNumb])
			elif isAce:
				series.insert(0, jokerList[jokerNumb])
			else:#highly unlikely scenario where they play all suits in one play with extra joker
				return False

	optionalJokersPresent = False
	if optionalJokers[0] and optionalJokers[1]:
		optionalJokersPresent = True
		series.append(optionalJokers)

	for cardIndex in range(len(series)):
		for replaceCard in replaceCards:
			if series[cardIndex] == replaceCard[0]:
				series[cardIndex] = replaceCard[1]

	return [True, optionalJokersPresent, series]
def removeDuplicates(seq):
	#most optimal way to remove duplicates is to use the function set()
    seen = set()
    seen_add = seen.add
    return [x for x in seq if x not in seen and not seen_add(x)]
def keepOnlyDuplicates(cardList):
	return [key for key,group in groupby(sorted(cardList)) if len(list(group)) > 1]
def getPairFrequency(pairHand):
	handBySuit = [0,0,0,0]
	for card in pairHand:
		handBySuit[int(floor((card%54)/13))] += 1
	return handBySuit
def getMissingSuites(pairHand, returnAsJokers = False):
	if len(pairHand):
		numberOfpairHand = (pairHand[0]%54)%13
		editedPairHand = [card%54 for card in pairHand]
		suitFreq = getPairFrequency(pairHand)
		
		if min(suitFreq) > 0:
			#removes all duplicates
			editedPairHand = keepOnlyDuplicates(editedPairHand)
		
		missingSuitesList = list(set(range(numberOfpairHand, 52, 13)) - set(editedPairHand))
		
		if returnAsJokers:
			return [x%54+108 for x in missingSuitesList]
		else:
			return missingSuitesList
	return []
def checkIfValidDown(cards):
	if 2 < len(cards) < 14:
		if not checkForDuplicates(cards) and onlyOneSuit(cards):
			return isSequence(cards)
		else:
			return checkForPairs(cards)
	return False
def convertAINumberToAILocation(AINumber):
	d = {0:"left", 1: "top", 2:"right"}
	return d[AINumber%3]
def convertCardToName(cardNum, longname = False):
	suit_options = { 0 : 'Clubs', 1 : 'Diamonds', 2 : 'Spades', 3 : 'Hearts'}
	card_name = { 0 : 'Ace', 1 : 'Two', 2 : 'Three', 3 : 'Four', 4 : 'Five', 5 : 'Six', 6 : 'Seven', 7 : 'Eight', 8 : 'Nine', 9 : 'Ten', 10: 'Jack', 11: 'Queen', 12: 'King'}

	if isJoker(cardNum):
		if longname: return 'Joker'
		else: return 'W'

	if longname:
		return card_name[cardNum%54%13] + ' of ' + suit_options[floor((cardNum%54)/13)]
	else:
		if cardNum%54%13==0 or cardNum%54%13 > 9:
			return suit_options[floor((cardNum%54)/13)][0] + ' ' + card_name[cardNum%54%13][0]
		return suit_options[floor((cardNum%54)/13)][0] + ' ' + str(cardNum%54%13+1)
def printSmallDeck():
	#simplish function that prints from top left to lower left
	global downPlayerCards, smallCardImages
	
	slotCounter = 0
	yvalue = 425
	setXValue = 130

		# 0-9 , 0-107, Rects
	for eachDownSet in downPlayerCards:
		cardXValues = findSpread(len(eachDownSet), 120)
		cardCounter = 0
		for xCoord in cardXValues:
			cardInt = eachDownSet[cardCounter][1][1] if isinstance(eachDownSet[cardCounter][1], tuple) else eachDownSet[cardCounter][1]
			if cardInt > 107:   cardInt = 52
			image = smallCardImages[cardInt%54]
			eachDownSet[cardCounter][2] = screen.blit(image, (xCoord-cardDimensions[0]/4+setXValue, yvalue))
			cardCounter += 1
		slotCounter += 1
		if slotCounter%5==0:
			yvalue += 70
			setXValue = 130
		else:
			setXValue += 150
def displayTurnArrow():
	global turnNumber, turnArrow, screenDimensions
	screen.blit(turnArrow[turnNumber], (screenDimensions[0]/2-16, screenDimensions[1]/4))
def displayAll(skipButtonActive=False):
	global numberOfSelectedCards, gameMode, dropButton, skipButton, playButton, skipButtonX, skipButtonY, screen
	
	screen.blit(background, (0, 0))
	displayBottom()
	if skipButtonActive:
		skipButton.create_button(screen, (65,105,225), skipButtonX, skipButtonY, buttonDimensions[0], buttonDimensions[1], 0, "Skip Buy", (255,255,255), 26)
	if isPlayButton:
		playButton.create_button(screen, (65,105,225), playButtonX, playButtonY, 50, 25, 0, "Play", (255,255,255), 20)
	if numberOfSelectedCards == 1:
		dropButton.create_button(screen, (65,105,225), dropButtonX, dropButtonY, 50, 25, 0, "Drop", (255,255,255), 20)
	if numberOfSelectedCards > 1:
		deselectallButton.create_button(screen, (65,105,225), deselectallButtonX, deselectallButtonY, 80, 25, 0, "Deselect All", (255,255,255), 20)
	printSmallDeck()
	printSmallAICards()
	displayAIcards()
	displayPilecards()
	displayTurnArrow()
def activateJokerMode():
	clockObject = pygame.time.Clock()
	jokerMode = True
	while jokerMode:
		testMenu.pressed(pygame.mouse.get_pos())
		testMenu.draw_menu(screen)
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == MOUSEBUTTONDOWN and event.button == 1 and testMenu.pressed(event.pos):
				jokerPlacedAs = testMenu.pressed(event.pos)
				#(SLOT, CARDNUM)
				jokerMode = False
			pygame.display.update()
			clockObject.tick(60)
	return jokerPlacedAs
def findJokerLocation(formattedHand):
	#FORMAT: [23, 24, [[53], [22, 25]]]
	
	jokerPlacedAsList = []

	#Seperate the 3 sections of the formattedHand into their distinctive pieces
	jokerlist = formattedHand[-1][0]
	possiblities = formattedHand[-1][1]
	regularHand = formattedHand[:-1]

	print(formattedHand)

	listOfCardNames = [(card, convertCardToName(card, longname=True)) for card in possiblities]
	testMenu.create_menu(screen, 100, 100, 300, 300, listOfCardNames, 32)

	jokerPlacedAs = activateJokerMode()
	regularHand.append(jokerPlacedAs[1]%54+108)
	jokerlist.pop()

	if jokerlist:
		regularHand = checkIfValidDown(regularHand + jokerlist)
		print("2nd Call", formattedHand)
		if isinstance(regularHand[-1][-1], list):
			regularHand = findJokerLocation(regularHand[-1])
			print("RUN AGAIN")

	return specialSort(regularHand)
def reEnumerateList(enumarateListAtIndex0):
	reenumerateNumber = 0
	for card in enumarateListAtIndex0:
		card[0] = reenumerateNumber
		reenumerateNumber += 1
	return enumarateListAtIndex0
def playCardDecision(mouseloc):
	global pileCardsRect, skipButton
	if skipButton.pressed(mouseloc):
		print("did not take card")
		return 0
	elif pileCardsRect[0].collidepoint(mouseloc):
		print("wants card")
		return 1
	return -1		
def playerPlayCards():
	print "DECSIIOSN TIMESSSSSSSSSS!!!!"
	displayAll(skipButtonActive=True)
	pygame.display.update()
	while True:
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == MOUSEBUTTONDOWN and event.button == 1:
				decision = playCardDecision(event.pos)
				if decision != -1:
					return decision
		clockObject.tick(60)
def noOverlap(overAllhand, hands):
	initalOverallLength = len(overAllhand)
	initalHandsLength = len(hands)
	listHands = []
	
	handsJokers = 0
	for x in hands:
		if isJoker(x) or x > 107:
			hands.remove(x)
			handsJokers += 1
	overAllJokers = 0
	for x in overAllhand:
		if isJoker(x) or x > 107:
			overAllJokers += 1
		elif x in hands:
			hands.remove(x)
	if not hands and overAllJokers >= handsJokers:
		return True
	else:
		return False
def getRidOfCards(AINumber, plays):
	global AICards, downAICards
	
	for handPlay in plays:
		jokersToRemove = 0
		for cardIndex in range(len(handPlay)):
			if isJoker(handPlay[cardIndex]) or handPlay[cardIndex] > 107:
				jokersToRemove += 1
		#http://stackoverflow.com/questions/6022764/python-removing-list-element-while-iterating-over-list
		for AIcardIndex in xrange(len(AICards[AINumber])-1, -1, -1): #remove all the jokers in the suggested hands
			cardInt = AICards[AINumber][AIcardIndex]
			if isJoker(cardInt) or cardInt > 107:
				del AICards[AINumber][AIcardIndex]
				jokersToRemove -= 1
			if cardInt%54 in handPlay:
				del AICards[AINumber][AIcardIndex]
				
		listOfHand = [[0, cardInt, 0] for cardInt in handPlay]
		downAICards[AINumber].append(listOfHand)
def playAICards(AINumber):
	global AICards, pileCards, isLastVisibleDeckCard, DeckCards, playerCards, roundNumber
	print("Start of " + convertAINumberToAILocation(AINumber) + "(" + str(AINumber) + ") AI's turn.")

	wantedCards = rateCards(AICards[AINumber])
	
	#buying phase
	if isLastVisibleDeckCard:
		topDeckCard = pileCards[-1]
		for i in range(AINumber,3):
			if topDeckCard in rateCards(AICards[i]):
				print("AI #" + str(i) + " took card:" + convertCardToName(topDeckCard, longname=True))
				AICards[AINumber].append(pileCards.pop())
				if i != AINumber:
					AICards[AINumber].append(DeckCards.pop())
				isLastVisibleDeckCard = False
				break
			else:
				print("AI #" + str(i) + " did not buy the card.")
		if isLastVisibleDeckCard and AINumber != 0:
			decision = playerPlayCards()
			if decision == 1: #if the player took the card
				playerCards.append([len(playerCards), pileCards.pop(), False, 0])
				playerCards.append([len(playerCards), DeckCards.pop(), False, 0])
				playerCards = specialSortSubLists(playerCards)
				isLastVisibleDeckCard = False
			else: #if player skipped
				for i in range(AINumber):
					if topDeckCard in rateCards(AICards[i]):
						print("AI #" + str(i) + " took card:" + convertCardToName(topDeckCard, longname=True))
						AICards[AINumber].append(pileCards.pop())
						AICards[AINumber].append(DeckCards.pop())
						isLastVisibleDeckCard = False
						break
					else:
						print("AI #" + str(i) + " did not buy the card.")
	#playing phase
	if not downAICards[AINumber]:
		possiblePlays = whatCanIplay(AICards[AINumber], minLength=gameOrder[roundNumber][1], maxLength=gameOrder[roundNumber][1])
		if gameOrder[roundNumber][0] == 2: #if two sets are needed
			for playCombination in combinations(possiblePlays, 2):
				if noOverlap(AICards[AINumber], playCombination[0]+playCombination[1]):
					getRidOfCards(AINumber, playCombination) #delete the cards from AI hand and put them in the down pile
					break
		elif gameOrder[roundNumber][0] == 1 and possiblePlays:
			print possiblePlays
			getRidOfCards(AINumber, [possiblePlays[0]])
	else:
		AICards[AINumber] = addToDownPileIfPossible(AICards[AINumber])
		possiblePlays = whatCanIplay(AICards[AINumber])
		while possiblePlays: #play as many hands as possible
			getRidOfCards(AINumber, [random.choice(possiblePlays)])
			possiblePlays = whatCanIplay(AICards[AINumber])
	if not AICards[AINumber]:
		roundOver()
			
	#dropping phase
	worstCard = getWorstCards(AICards[AINumber])
	print("AI #" + str(AINumber) + " getting rid of: " + convertCardToName(worstCard, longname=True) + "/ " + str(worstCard) + " .")
	pileCards.append(AICards[AINumber].pop(AICards[AINumber].index(worstCard)))
	print("on pile right now: " + convertCardToName(pileCards[-1], longname=True) + " ", pileCards)

	isLastVisibleDeckCard = True
	if not AICards[AINumber]:
		roundOver()
	
	
	print("AI #" + str(AINumber) + " has ended his turn")
	endTurn()
def changeGameMode():
	global gameMode
	gameMode = 2 - (gameMode+1)%2
	##1 = PlayerPhase 2 Start of turn where player must take a card		
def endTurn():
	global turnNumber, gameMode
	turnNumber = (turnNumber+1)%4 #Presuming four players
	changeGameMode()
	if turnNumber == 0:
		changeGameMode()
	else:
		playAICards((turnNumber-1))		
def checkForDownPilesLocation(selectedCard, downRectPiles):
	global playerCards, numberOfSelectedCards
	
	possibleLocations = possibleAddLocations([num[1] for num in downRectPiles])
	#returns in the format [[cardInts], [indexes]]
	
	
	if isJoker(selectedCard):
		possibleLocationsForJoker = [card for card in possibleLocations[0] if not (isJoker(card) or card>107)]
		if len(possibleLocationsForJoker) > 1:
			listOfCardNames = [(card, convertCardToName(card, longname=True)) for card in possibleLocationsForJoker]
			testMenu.create_menu(screen, 100, 100, 300, 300, listOfCardNames, 32)
			jokerPlacedAs = activateJokerMode()[1]
			possibleLocationsForJoker = [jokerPlacedAs%54+108]
			
		indexOfPlacedJoker = 0
		for index in range(len(possibleLocations[0])):  
			if possibleLocationsForJoker[0]%54 == possibleLocations[0][index]%54:
				indexOfPlacedJoker = possibleLocations[1][index]
				break
		for playerIndex in range(len(playerCards)):
			if playerCards[playerIndex][2]:
				downRectPiles.insert(indexOfPlacedJoker,[0, possibleLocationsForJoker[0]%54+108, 0])
				downRectPiles = reEnumerateList(downRectPiles)
				playerCards.pop(playerIndex)
				numberOfSelectedCards = 0
				break
	else:
		listOfIndexes = [index for index in range(len(possibleLocations[0])) if selectedCard%54 == possibleLocations[0][index]%54]
		if len(listOfIndexes) >= 2:
			for arraySlot in listOfIndexes: 
				if isJoker(possibleLocations[0][arraySlot]) or possibleLocations[0][arraySlot]>107:
					arrayJokerIndex = arraySlot
				else:
					arrayNormalIndex = arraySlot
					
			testMenu.create_menu(screen, 100, 100, 300, 300, [(0,"Get Joker"), (1,"Don't")], 32)
			playAsJoker = not activateJokerMode()[0] #JOKER
			 
			if playAsJoker:
				downRectPiles[possibleLocations[1][arrayJokerIndex]] = [0, selectedCard, 0]
			else:
				downRectPiles.insert(possibleLocations[1][arrayNormalIndex],[0, selectedCard, 0])
			downRectPiles = reEnumerateList(downRectPiles)

			for playerIndex in range(len(playerCards)):
				if playerCards[playerIndex][2]:
					if playAsJoker:
						playerCards[playerIndex] = [0,53,False,0]
						playerCards = reEnumerateList(specialSortSubLists(playerCards))
						numberOfSelectedCards = 0
					else:
						playerCards.pop(playerIndex)
						numberOfSelectedCards = 0
					return								
		for index in range(len(possibleLocations[0])):
			if selectedCard%54 == possibleLocations[0][index]%54:
				if isJoker(possibleLocations[0][index]) or possibleLocations[0][index]>107:
					downRectPiles[possibleLocations[1][index]] = [0, selectedCard, 0]
				else:
					downRectPiles.insert(possibleLocations[1][index],[0, selectedCard, 0])
				downRectPiles = reEnumerateList(downRectPiles)

				for playerIndex in range(len(playerCards)):
					if playerCards[playerIndex][2]:
						if isJoker(possibleLocations[0][index]) or possibleLocations[0][index]>107:
							playerCards[playerIndex] = [0,53,False,0]
							playerCards = reEnumerateList(specialSortSubLists(playerCards))
							numberOfSelectedCards = 0
						else:
							playerCards.pop(playerIndex)
							numberOfSelectedCards = 0
						return
def possibleAddLocations(cardSet):
  possibleLocations = [[],[]] #CARD INT , INDEX
  
  for index in range(len(cardSet)):
    if isJoker(cardSet[index]) or cardSet[index]>107:
      possibleLocations[0].append(cardSet[index]%54+108)
      possibleLocations[1].append(index)
    
  if onlyOneSuit(cardSet):
    if (cardSet[0]%54)%13 > 0:
      possibleLocations[0].append(cardSet[0]%54-1)
      possibleLocations[1].append(0)
    if (cardSet[-1]%54)%13 < 12:
      possibleLocations[0].append(cardSet[-1]%54+1)
      possibleLocations[1].append(len(cardSet))
  else:
    cardNumbSuit = (cardSet[0]%54)%13
    numberOfSuit = [0,0,0,0]
    for card in cardSet:
      numberOfSuit[int(floor((card%54)/13))] += 1
    lowestSuitPresence = min(numberOfSuit)
    twoSets = len(cardSet) >= 4
    suitNumber = 0
    for occurenceNum in numberOfSuit:
      if lowestSuitPresence==occurenceNum:
        possibleLocations[0].append(suitNumber*13 + cardNumbSuit)
        possibleLocations[1].append(twoSets*4 + suitNumber)
      suitNumber += 1
  return possibleLocations
def dropSelectedPlayerCards():
	global playerCards, numberOfSelectedCards
	for index in range(len(playerCards)):
		if playerCards[index][2]:
			numberOfSelectedCards = 0
			return playerCards.pop(index)
	if not playerCards:
		roundOver()
##AI FUNCTIONS##
def rateCards(hand, addRangeMulti=20, connectingTwoSeqMulti=20, addPairMulti=20):
	hand = specialSort(hand)
	jokerList = []
	listBySuit = [[],[],[],[]]
	listByNumber = [[],[],[],[],[],[],[],[],[],[],[],[],[]]
	ranges = [[],[],[],[]]
	
	for card in hand:
		if isJoker(card):
			jokerList.append(card)
		else:
			listBySuit[int(floor((card%54)/13))].append(card%54)
			listByNumber[(card%54)%13].append(card%54)
	
	for cardIndex in range(4):
		ranges[cardIndex] = [list(map(itemgetter(1), g)) for k,g in groupby(enumerate(listBySuit[cardIndex]), lambda i:i[0]-i[1])]
	goodCards = []
	
	cardMultiplier = 0.0
	
	for cardRange in ranges:
		lengthOfRanges = len(cardRange)
		for cardRangeIndex in range(lengthOfRanges):
			currentCardRange = cardRange[cardRangeIndex]
			cardMultiplier = (len(currentCardRange) + (len(currentCardRange) > 1))/5
			if currentCardRange[0]%13 != 0:
				goodCards.append((int(cardMultiplier*addRangeMulti),cardRange[cardRangeIndex][0]-1))
			if currentCardRange[-1]%13 != 12:
				goodCards.append((int(cardMultiplier*addRangeMulti),cardRange[cardRangeIndex][-1]+1))
			if cardRangeIndex != (lengthOfRanges-1): #if not last suit range to stop bad array acess
				difference = cardRange[cardRangeIndex+1][0] - cardRange[cardRangeIndex][-1] -1
				if difference < 3:
					totalCardsPlayable = int((difference-1) <= len(jokerList)) + len(cardRange[cardRangeIndex+1]) + len(currentCardRange)
					for numDifference in range(1,difference+1):
						bounsIfAppend = int(numDifference==1 or numDifference==difference)
						score = int((totalCardsPlayable+bounsIfAppend)/5*connectingTwoSeqMulti)
						goodCards.append((score, currentCardRange[-1]+numDifference))		
	for cardsSuit in listByNumber:
		numberOfPair = len(cardsSuit)
		numberOfDuplicates = checkForDuplicates(cardsSuit)
		if numberOfPair and ((not numberOfDuplicates) or (numberOfPair+len(jokerList)-numberOfDuplicates)>=4):
			missingSuitList = getMissingSuites(cardsSuit)
			cardMultiplier = (numberOfPair + int(numberOfPair > 1))/5
			for cardInt in missingSuitList:
				goodCards.append((int(cardMultiplier*addPairMulti), cardInt))
	goodCards = sorted(goodCards, key=itemgetter(0), reverse=True)
	goodCards = removeDuplicates([x[1] for x in goodCards])
	#returns the best cards in sequence
	return goodCards
def getWorstCards(hand):
	hand = specialSort(hand)
	jokerList = []
	badCards = []
	listBySuit = [[],[],[],[]]
	listByNumber = [[],[],[],[],[],[],[],[],[],[],[],[],[]]
	
	highValueCards = []
	
	for card in hand:
		if isJoker(card):
			jokerList.append(card)
		else:
			listBySuit[int(floor((card%54)/13))].append(card%54)
			listByNumber[(card%54)%13].append(card%54)
			if not highValueCards or (card%54)%13 > (highValueCards[0]%54)%13:
				highValueCards = [card]
			elif (card%54)%13 == (highValueCards[0]%54)%13:
				highValueCards.append(card)
	
	for pairSet in listByNumber + listBySuit:
		listOfDups = checkForDuplicates(pairSet, returnList=True)
		if listOfDups and len(pairSet)<=4:
			for duplicateCard in listOfDups:
				badCards += listOfDups
				
	worstDupCard = -1
	for card in badCards:
		if (card%54)%13 >= 9:
			return card
		elif (card%54)%13 > (worstDupCard%54)%13:
			worstDupCard = card
	if worstDupCard != -1:
		return worstDupCard
	
	random.shuffle(highValueCards)
	for highCard in highValueCards:
		if len(listByNumber[(card%54)%13]) < 3 and listBySuit[int(floor((card%54)/13))%4] < 3:
			return highCard
			
	return random.choice(highValueCards)
def whatCanIplay(hand, maxLength = 13, minLength = 3):
	hand = specialSort(hand)
	jokerList = []
	listBySuit = [[],[],[],[]]
	listByNumber = [[],[],[],[],[],[],[],[],[],[],[],[],[]]
	ranges = [[],[],[],[]]
	possiblePlays = []
	
	for card in hand:
		if isJoker(card):
			jokerList.append(card)
		else:
			listBySuit[int(floor((card%54)/13))].append(card%54)
			listByNumber[(card%54)%13].append(card%54)
	numberOfJokers = len(jokerList)
	
	for cardIndex in range(4):
		ranges[cardIndex] = [list(map(itemgetter(1), g)) for k,g in groupby(enumerate(listBySuit[cardIndex]), lambda i:i[0]-i[1])]
	
	for suitRange in ranges:
		previousRange = []
		for singleRange in suitRange:
			lengthOfSingleRange = len(singleRange)
			if lengthOfSingleRange >= minLength:
				possiblePlays.append(singleRange[0:maxLength])
			if previousRange:
				difference = singleRange[0] - previousRange[-1] - 1
				if difference <= numberOfJokers and difference > 0:
					jokerActingAsNumbers = list(range(previousRange[-1]+109, singleRange[0]+108))
					mergedRange = previousRange + jokerActingAsNumbers + singleRange
					if len(mergedRange) >= minLength:
						possiblePlays.append(mergedRange[0:maxLength])
			previousRange = singleRange
				
	numberOfNumberList = 0
	for numberList in listByNumber:
		lengthOfNumberList = len(numberList)
		jokerLocations = getMissingSuites(numberList, returnAsJokers=True)
		numberOfJokerLocations = len(jokerLocations)
		numberOfDuplicates = checkForDuplicates(numberList)

		if lengthOfNumberList and (lengthOfNumberList + numberOfJokers) >= minLength and ((not numberOfDuplicates) or (lengthOfNumberList+numberOfJokers-numberOfDuplicates)>=4):
			if numberOfDuplicates > 0 and numberOfJokers >= numberOfJokerLocations:
				mergedList = numberList + jokerLocations
				jokerLocations = getMissingSuites(mergedList, returnAsJokers=True)
				mergedList += jokerLocations[0:(numberOfJokers-numberOfJokerLocations)]
				possiblePlays.append(mergedList[0:maxLength])
			elif numberOfDuplicates == 0:
				addJokers = jokerLocations[0:numberOfJokers]
				numberOfAddJokers = len(addJokers)
				mergedList = numberList + addJokers
				if (numberOfJokers-numberOfJokerLocations) > 0: #if there are jokers left to assign
					jokerLocations = getMissingSuites(mergedList, returnAsJokers=True)
					mergedList += jokerLocations[0:(numberOfJokers-numberOfAddJokers)]
				possiblePlays.append(mergedList[0:maxLength])
	return possiblePlays
##END OF AI FUNCTIONS##	
def playerButtons(mouseloc):
	global roundNumber, downAICards, gameOrder, playerCards,firstSetDown,downPlayerCards,isLastVisibleDeckCard, pileCardsRect, playButton, isPlayButton, numberOfSelectedCards, dropOnly
	if dropOnly:
		if dropButton.pressed(mouseloc) and numberOfSelectedCards==1:
			pileCards.append(dropSelectedPlayerCards()[1])
			isLastVisibleDeckCard = True
			dropOnly = False
			endTurn()
		else:
			for cardRect in reversed(playerCards):
				# 0-9 , 0-107, T/F, Rects
				if cardRect[3].collidepoint(mouseloc):
					print("Selected Card", cardRect[1], "(" + str(cardRect[0]) + ")")
					cardRect[2] = not cardRect[2]
					break
		return
	
	if dropButton.pressed(mouseloc) and numberOfSelectedCards==1:
		if not firstSetDown:
			firstSetDown = (len(downPlayerCards) == gameOrder[roundNumber][0] and all(gameOrder[roundNumber][1] == len(hand) for hand in downPlayerCards))
		if not downPlayerCards or firstSetDown:		
			pileCards.append(dropSelectedPlayerCards()[1])
			LastVisibleDeckCard = True
			if not playerCards:
				roundOver()
			endTurn()
		else:
			for hand in downPlayerCards:
				for card in hand:
					if isJoker(card[1]) or card[1]>107:
						playerCards.append([0,53,False,0])
					else:
						playerCards.append([0,card[1],False,0])
			playerCards = reEnumerateList(specialSortSubLists(playerCards))
			for item in playerCards:
				item[2] = False
			numberOfSelectedCards = 0
			downPlayerCards = []
		
	elif playButton.pressed(mouseloc) and isPlayButton:
		print("PLAY DOWN")
		if isPlayButton[1]:
			isPlayButton[2] = findJokerLocation(isPlayButton[2])#ask where jokers go
			print("JOKER CHOOOOOSE", isPlayButton)
			
		selectedCards = []
		counter = 0
		for item in isPlayButton[2]:
			selectedCards.append([counter, item, 0])
			counter += 1
		playerCards = [value for value in playerCards if not value[2]]
		downPlayerCards.append(selectedCards)
		numberOfSelectedCards = 0

		# 0-9 , 0-107, T/F, Rects
		#remove all the selected cards from the player's hand

		isPlayButton = False
		if not playerCards:
			roundOver()
	elif deselectallButton.pressed(mouseloc) and numberOfSelectedCards>1:
		for item in playerCards:
			item[2] = False
		numberOfSelectedCards = 0
	else:
		for cardRect in reversed(playerCards):
			# 0-9 , 0-107, T/F, Rects
			if cardRect[3].collidepoint(mouseloc):
				print("Selected Card", cardRect[1], "(" + str(cardRect[0]) + ")")
				cardRect[2] = not cardRect[2]
				break
		selectedCardsList = [item[1] for item in playerCards if item[2]]
		numberOfSelectedCards = len(selectedCardsList)
		isPlayButton = checkIfValidDown(selectedCardsList)
			
		if numberOfSelectedCards == 1 and firstSetDown:
			for downRectPiles in downPlayerCards:
			# 0-9 , 0-107, Rects
				for cardRect in reversed(downRectPiles):
					if cardRect[2].collidepoint(mouseloc):
						checkForDownPilesLocation(selectedCardsList[0], downRectPiles)
						break
			for singleAIDownCards in downAICards:
				for downRectPiles in singleAIDownCards:
					for cardRect in reversed(downRectPiles):
						if cardRect[2].collidepoint(mouseloc):
							checkForDownPilesLocation(selectedCardsList[0], downRectPiles)
							break
			if not playerCards:
				roundOver()
	print("*Click*")
def startOfTurnButtons(mouseloc):
	global pileCardsRect, DeckCards, pileCards, isLastVisibleDeckCard, playerCards
	if pileCardsRect[0].collidepoint(mouseloc) and isLastVisibleDeckCard and pileCards:
		playerCards.append([len(playerCards), pileCards.pop(), False, 0])
		playerCards = specialSortSubLists(playerCards)
		isLastVisibleDeckCard = False
		changeGameMode()
	elif pileCardsRect[1].collidepoint(mouseloc):
		print("Selected Right card")
		playerCards.append([len(playerCards), DeckCards.pop(), False, 0])
		playerCards = specialSortSubLists(playerCards)
		changeGameMode()
		
def updateMessage(mouseloc):
	pass
	#print("Mouse loc", mouseloc, "GAME MODE", gameMode)		

def whatButton(mouseloc):
	global gameMode
	if gameMode == 1: ##PlayerPhase:
		playerButtons(mouseloc)
	elif gameMode == 2:##Start of turn where player must take a card
		startOfTurnButtons(mouseloc)
	
	updateMessage(mouseloc)
	displayAll()

def playDownWhereValid(cardGroup, cards):
	numberOfChanges = 0
	
	for index in range(len(cardGroup)):
		if cardGroup[index][1] > 107 and (cardGroup[index][1]%54) in cards:
			cardGroup[index][1] = cards.pop(cards.index(cardGroup[index][1]%54))
			cards.append(53)
			numberOfChanges += 1
	
	cardIntsOnly = [tripleCard[1] for tripleCard in cardGroup]
	if onlyOneSuit(cardIntsOnly):
		if(cardGroup[0][1]%54)%13 != 0 and (cardGroup[0][1]%54-1) in cards:
			cardGroup.insert(0, [0, cards.pop(cards.index(cardGroup[0][1]%54-1)), 0])
			numberOfChanges += 1
		if(cardGroup[-1][1]%54)%13 != 12 and (cardGroup[-1][1]%54+1) in cards:
			cardGroup.append([0, cards.pop(cards.index(cardGroup[-1][1]%54+1)), 0])
			numberOfChanges += 1
	else:
		listOfMissingNumbers = getMissingSuites(cardIntsOnly)
		listOfSameNumber = [i for i in listOfMissingNumbers if i in cards]
		for similarNumber in listOfSameNumber:
			cardGroup.append([0,cards.pop(cards.index(similarNumber)),0])
			numberOfChanges += 1
	if numberOfChanges:
		print("AI added to deck", numberOfChanges, "changes")
	return cards
	
def addToDownPileIfPossible(cards):
	global downAICards, downPlayerCards
	for singleAIDownCards in downAICards:
		for singleDownHand in singleAIDownCards:
			if playDownWhereValid(singleDownHand, cards)[0] != 0:
				cards = playDownWhereValid(singleDownHand, cards)
			
	for singleDownHand in downPlayerCards:
		if playDownWhereValid(singleDownHand, cards)[0] != 0:
			cards = playDownWhereValid(singleDownHand, cards)
	return cards
#main
def countPointsInHand(hand):
	pts = 0
	for cardInt in hand:
		if isJoker(cardInt): #jokers are worth 15 points
			pts += 15
		elif (cardInt%54)%13 >= 9: #all facecards and ten are worth ten points
			pts += 10
		else:
			pts += (cardInt%54)%13+1 #otherwise numbervalue of card
	return pts
			
def roundOver():
	global roundNumber, firstSetDown, scoreTally
	
	scoreTally[0][1] = countPointsInHand([x[1] for x in playerCards])
	for AINumber in range(3):
		scoreTally[AINumber+1][1] = countPointsInHand(AICards[AINumber])
	scoreTally.sort(key=lambda x: x[1]) #sort by second element
	
	firstSetDown = False
	roundNumber += 1
	print("1x3 Rummy BETA Finished (more round coming soon, maybe)")
	print("---FINAL TALLY---")
	for tally in scoreTally:
		identitiy = "Player: "
		if tally[0] != 0:
			identitiy = "AI #" + str(tally[0]-1) + ":"
		print(identitiy, tally[1])
	print("-----------------")
	pygame.quit()
	sys.exit()

if __name__ == '__main__':
	pygame.init()
	random.seed()
	screenDimensions = (1000, 700)
	buttonDimensions = (100, 50)
	cardDimensions = (75, 107)
	screen = pygame.display.set_mode(screenDimensions) #perhaps incorporate an option where the player can choose the screen size, after everything is done of course
	pygame.display.set_caption('Rummy Testing')
	
	background = pygame.Surface(screen.get_size()).convert()
	background.fill((1, 50, 32))
	
	screen.blit(background, (0, 0))
	pygame.display.flip()
	
	DeckCards = list(range(54)*2)
	#cards is a list of all the cards possible in game (2 decks):
	#clubs (0-12), diamonds(13-25), hearts(26-38), spades(39-51), 2 jokers (52-53)
	#clubs (54-66), diamonds (67-79), hearts (80-92), spades (93-105), 2 jokers (106-107)
	
	#preload sounds
	#clickSound = pygame.mixer.Sound('Sounds/click.wav')
	
	#preload images
	transcard = pygame.image.load('Images/General/transcard.png').convert_alpha()
	backOfCard = pygame.image.load('Images/General/backRed.png').convert_alpha() #Sets the 'back of the card' image
	backOfCardSmall = pygame.image.load('Images/General/backRedSmall.png').convert_alpha()
	turnArrow = [pygame.image.load('Images/General/arrowDown.png').convert_alpha(),
				pygame.image.load('Images/General/arrowLeft.png').convert_alpha(),
				pygame.image.load('Images/General/arrowUp.png').convert_alpha(),
				pygame.image.load('Images/General/arrowRight.png').convert_alpha()]
	turnNumber = 0
	
	cardImages = []
	cardHighLights = []
	smallCardImages = []
	
	for cardNum in range(54):
		cardPic = load_image('Images/Cards/', str(cardNum) + '.png')
		cardImages.append(cardPic)
		cardPic = pygame.transform.scale(cardPic, (45, 64))
		smallCardImages.append(cardPic)
		cardHighLights.append(load_image('Images/Cards/', str(cardNum) + 'hl.png'))
		
		
	numberOfCardsDealt = 10
	AICards = [getRandomDeckCards(DeckCards, numberOfCardsDealt) for i in range(3)]
	
	#0-9= position in hand, 0-107 for the card numer, T/F for if selected, and 0 for the rect (updated later)
	playerCards = [[sn,e1,e2,0] for sn,e1,e2 in zip(range(numberOfCardsDealt), getRandomDeckCards(DeckCards, numberOfCardsDealt), [False]*numberOfCardsDealt)]
	
	downAICards = [[],[],[]] #left, top, right
	downPlayerCards = []
	scoreTally = [[0,0], [1,0], [2,0], [3,0]]
	
	roundNumber = 0
	gameOrder = [(1,3), (2,3), (1,4), (2,4), (1,5), (2,5)]
	gameMode = 2
	firstSetDown = False
	dropOnly = False
	tookCardThisTurn = False
	
	displayAIcards()
	displayBottom()
	
	isLastVisibleDeckCard = True
	pileCards = getRandomDeckCards(DeckCards, 1)
	pileCardsRect = displayPilecards()
	
	#preload buttons
	skipButton = Buttons.Button()
	skipButtonX, skipButtonY = int(screenDimensions[0]/2-buttonDimensions[0]/2), int((screenDimensions[1]-buttonDimensions[1])/1.8)
	skipButton.create_button(screen, (65,105,225), skipButtonX, skipButtonY, buttonDimensions[0], buttonDimensions[1], 0, "Skip Buy", (255,255,255), 26)
	
	playButton = Buttons.Button()
	playButtonX,playButtonY = int((screenDimensions[0]-50)*.975), int((screenDimensions[1]-25)*.89)
	playButton.create_button(screen, (65,105,225), playButtonX, playButtonY, 50, 25, 0, "Play", (255,255,255), 20)
	
	dropButton = Buttons.Button()
	dropButtonX,dropButtonY = int((screenDimensions[0]-50)*.975), int((screenDimensions[1]-25)*.96)
	dropButton.create_button(screen, (65,105,225), dropButtonX, dropButtonY, 50, 25, 0, "Drop", (255,255,255), 20)
	
	deselectallButton = Buttons.Button()
	deselectallButtonX,deselectallButtonY = int((screenDimensions[0]-50)*.01), int((screenDimensions[1]-25)*.96)
	deselectallButton.create_button(screen, (65,105,225), deselectallButtonX, deselectallButtonY, 80, 25, 0, "Deselect All", (255,255,255), 20)
	
	testMenu = menuClass.Menu()
	testMenu.create_menu(screen, 100, 100, 300, 300, [(10,"Ten of Hearts"),(12,"Ten of Spades"),(14,"Ten of Diamonds"),(16,"Ten of Clubs")], 32)
	
	isPlayButton = False
	numberOfSelectedCards = 0
	displayAll()


	clockObject = pygame.time.Clock()
	while True:
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == KEYDOWN:
				pass
			elif event.type == MOUSEBUTTONDOWN and event.button == 1:
				whatButton(event.pos)				

		pygame.display.update()
		clockObject.tick(60)