import pygame
from pygame.locals import *
pygame.init()
class Menu:
	def __init__(self):
		self.hovered = -1
	
	def create_menu(self, surface, x, y, width, height, textlist, font_size):
		self.rect = (x,y, width, height)
		self.font_size = font_size
		self.textlist = textlist
		self.draw_menu(surface)
	
	def draw_menu(self, surface):
		divider = len(self.textlist)+2
		pygame.draw.rect(surface, (120,120,0), self.rect, 0)
		self.write_text(surface, "USE JOKER AS:", (255,255,255), self.rect[3]/(divider+1), self.font_size+2)
		self.rects = []
		iterator=2
		for item in self.textlist:
			self.rects.append(self.write_text(surface, item[1], ((255, 255, 255) if self.hovered==(iterator-2) else (100, 100, 100)), iterator*self.rect[3]/divider, self.font_size))
			iterator += 1
	
	def write_text(self, surface, text, text_color, height, font_size):
		textDisc = pygame.font.Font(None, font_size).render(text, True, text_color)
		textpos = textDisc.get_rect(center=(self.rect[2]/2+self.rect[0],height+self.rect[1]))
		surface.blit(textDisc, textpos)
		return textpos		
		
	def pressed(self, mouse):
		iterator = 0
		for rect in self.rects:
			if rect.collidepoint(mouse):
				self.hovered = iterator
				return (iterator, self.textlist[iterator][0])
			iterator += 1
		self.hovered = -1
		return False
